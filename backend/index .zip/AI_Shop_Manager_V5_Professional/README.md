# AI Shop Manager V5 — Real AI Conversation Engine

## What changed
The `/api/analyze-conversation` endpoint now uses the OpenAI Responses API when
`OPENAI_API_KEY` is configured. It requests Structured Outputs using a JSON Schema,
then returns a sale object for the UI to review. Structured Outputs are the preferred
way to constrain JSON responses in the Responses API. See the official API reference:
https://developers.openai.com/api/reference/cli/resources/responses/methods/create

## Safety
The AI endpoint ONLY extracts a proposed sale. It does not mutate stock or customer
balances. `/api/confirm-sale` performs the database mutation only after the user confirms.

## Setup
1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env`
3. Put your API key in `.env` on the backend machine.
4. `uvicorn main:app --reload`
5. Open `http://127.0.0.1:8000`

If the API key is missing or the AI call fails, the app falls back to the demo parser
so the UI remains testable.

## Example
Conversation:
"रमेशला दोन साबण आणि एक शॅम्पू दिला. एकूण 200 रुपये. त्याने 150 रुपये दिले."

Expected proposal:
customer=Ramesh, items=[Soap x2, Shampoo x1], total=200, paid=150, pending=50.

Always verify the proposed sale before confirming it.


## Render deployment for this V5 layout

This version uses FastAPI/Python (`main.py`), not Node/Express.

- Root Directory: leave blank (repository root)
- Build Command: `pip install -r requirements.txt`
- Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Environment variable: `OPENAI_API_KEY` (server-side only)
- Optional: `OPENAI_MODEL`
- Optional: `SHOP_DB`

If the frontend is hosted on GitHub Pages, open Settings (⚙️) in the web app and enter the Render backend URL, for example `https://your-service.onrender.com`.

Never put an API key in `web/index.html` or an Android APK.
