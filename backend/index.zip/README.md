# AI Shop Manager V6 — Beautiful UI

Colorful, responsive, animated dashboard UI for the AI Shop Manager.
Replace the existing `web/index.html` with this file. Demo values are placeholders;
connect the V5 FastAPI endpoints for live data and real AI conversation processing.
