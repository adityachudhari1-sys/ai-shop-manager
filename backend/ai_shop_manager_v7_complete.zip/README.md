# AI Shop Manager V7 Complete

Merged build:
- V6 colorful animated responsive UI
- V5 FastAPI + SQLite backend
- Real-AI conversation endpoint when `OPENAI_API_KEY` is configured
- Sale proposal modal with editable customer, quantity and unit price
- Confirm Sale required before stock/customer transaction mutation
- Live dashboard, inventory, customers and report

## Run locally
```bash
pip install -r requirements.txt
cp .env.example .env
# add OPENAI_API_KEY to .env on the backend machine
uvicorn main:app --reload
```
Then open `http://127.0.0.1:8000`.

Never put the API key in `web/index.html`, GitHub Pages, or an Android APK.
The frontend is designed to be served by the FastAPI app so API calls use the same origin.
