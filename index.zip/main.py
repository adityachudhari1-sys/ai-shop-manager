import os, json, sqlite3
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

DB = os.getenv("SHOP_DB", "shop.db")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")

app = FastAPI(title="AI Shop Manager API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      price REAL NOT NULL DEFAULT 0,
      stock INTEGER NOT NULL DEFAULT 0,
      sold INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS customers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      pending REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer TEXT,
      items_json TEXT NOT NULL,
      total REAL NOT NULL,
      paid REAL NOT NULL,
      pending REAL NOT NULL,
      created_at TEXT NOT NULL
    );
    """)
    count = c.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if count == 0:
        c.executemany("INSERT INTO products(name,price,stock) VALUES(?,?,?)", [
            ("Soap",40,50), ("Shampoo",120,30), ("Rice",60,40), ("Oil",150,20)
        ])
    c.commit(); c.close()

init_db()

class Conversation(BaseModel):
    transcript: str
    language: str = "mr-IN"

class Item(BaseModel):
    product: str
    quantity: int
    unit_price: float = 0

class Sale(BaseModel):
    customer: Optional[str] = None
    items: List[Item]
    total: float
    paid: float = 0

def demo_parse(text):
    low = text.lower()
    products = []
    aliases = {
      "soap": ["soap","साबण","साबुन"],
      "shampoo": ["shampoo","शॅम्पू","शैम्पू"],
      "rice": ["rice","तांदूळ","चावल"],
      "oil": ["oil","तेल"]
    }
    nums = ["one","एक","एकं","1","two","दोन","२","2","three","तीन","३","3","four","चार","४","4","five","पाच","५","5","six","सहा","६","6","seven","सात","७","7","eight","आठ","८","8","nine","नऊ","९","9","ten","दहा","१०","10"]
    val = {"one":1,"एक":1,"एकं":1,"1":1,"two":2,"दोन":2,"२":2,"2":2,"three":3,"तीन":3,"३":3,"3":3,"four":4,"चार":4,"४":4,"4":4,"five":5,"पाच":5,"५":5,"5":5,"six":6,"सहा":6,"६":6,"6":6,"seven":7,"सात":7,"७":7,"7":7,"eight":8,"आठ":8,"८":8,"8":8,"nine":9,"नऊ":9,"९":9,"9":9,"ten":10,"दहा":10,"१०":10,"10":10}
    for key, words in aliases.items():
        if any(w.lower() in low for w in words):
            q = 1
            for n in nums:
                if n.lower() in low:
                    q = val[n]; break
            products.append({"product":key.title(),"quantity":q,"unit_price":0})
    import re
    money = re.findall(r"(?:₹|rs\.?|रुपये|रुपया)\s*([0-9]+(?:\.[0-9]+)?)|([0-9]+(?:\.[0-9]+)?)\s*(?:₹|rs\.?|रुपये|रुपया)", low)
    amounts = [float(a or b) for a,b in money]
    paid = amounts[-1] if amounts else 0
    customer = None
    m = re.search(r"(?:customer|ग्राहक|रमेश|सुरेश)\s*[:\-]?\s*([A-Za-z\u0900-\u097F]+)?", text, re.I)
    if m and m.group(1): customer = m.group(1).title()
    return {"customer":customer,"items":products,"total":sum(i["quantity"]*i["unit_price"] for i in products),"paid":paid}

@app.get("/api/health")
def health():
    return {"ok":True,"ai_configured":bool(os.getenv("OPENAI_API_KEY")),"model":MODEL}

@app.get("/api/stock")
def stock():
    c=db(); rows=[dict(r) for r in c.execute("SELECT * FROM products ORDER BY name")]; c.close()
    return rows

@app.get("/api/customers")
def customers():
    c=db(); rows=[dict(r) for r in c.execute("SELECT * FROM customers ORDER BY name")]; c.close()
    return rows

@app.get("/api/report")
def report():
    c=db()
    r=c.execute("SELECT COALESCE(SUM(total),0) total, COUNT(*) orders, COALESCE(SUM(pending),0) pending FROM transactions WHERE date(created_at)=date('now','localtime')").fetchone()
    low=c.execute("SELECT name,stock FROM products WHERE stock<=5 ORDER BY stock").fetchall()
    c.close()
    return {"sales":r["total"],"orders":r["orders"],"pending":r["pending"],"low_stock":[dict(x) for x in low]}

@app.post("/api/analyze-conversation")
def analyze(req: Conversation):
    # Production hook: replace demo_parse with an OpenAI Responses API call.
    # Keep the API key server-side only. Validate AI JSON before showing it to the user.
    return {"source":"demo_parser","model":MODEL,"result":demo_parse(req.transcript)}

@app.post("/api/confirm-sale")
def confirm_sale(sale: Sale):
    c=db()
    total=0
    for it in sale.items:
        p=c.execute("SELECT * FROM products WHERE lower(name)=lower(?)",(it.product,)).fetchone()
        if not p: raise HTTPException(400,f"Product not found: {it.product}")
        if p["stock"] < it.quantity: raise HTTPException(400,f"Not enough stock: {it.product}")
        unit = it.unit_price or p["price"]
        total += unit*it.quantity
    if abs(total-sale.total)>0.01: total=sale.total
    pending=max(0,total-sale.paid)
    for it in sale.items:
        p=c.execute("SELECT * FROM products WHERE lower(name)=lower(?)",(it.product,)).fetchone()
        c.execute("UPDATE products SET stock=stock-?, sold=sold+? WHERE id=?",(it.quantity,it.quantity,p["id"]))
    if sale.customer:
        c.execute("INSERT OR IGNORE INTO customers(name,pending) VALUES(?,0)",(sale.customer,))
        c.execute("UPDATE customers SET pending=pending+? WHERE name=?",(pending,sale.customer))
    c.execute("INSERT INTO transactions(customer,items_json,total,paid,pending,created_at) VALUES(?,?,?,?,?,?)",
              (sale.customer,json.dumps([x.model_dump() for x in sale.items],ensure_ascii=False),total,sale.paid,pending,datetime.now().isoformat(timespec="seconds")))
    c.commit(); c.close()
    return {"ok":True,"total":total,"paid":sale.paid,"pending":pending}
