# AI Shop Manager — Real AI Backend Starter

This package upgrades the conversation workflow to a FastAPI + SQLite backend.

## Run
1. Python 3.10+
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Put your AI API key ONLY in `.env` on the server.
5. `uvicorn main:app --reload`
6. Open `http://127.0.0.1:8000/docs`

## API
- GET `/api/health`
- POST `/api/analyze-conversation`
- POST `/api/confirm-sale`
- GET `/api/stock`
- GET `/api/customers`
- GET `/api/report`

Important: the current analyzer intentionally uses a demo parser. It is not pretending to be a production AI connection. The next integration should call the Responses API on the server and force structured JSON, then validate it before confirmation.

The frontend is a minimal test console. It can send a conversation, show detected sale, and confirm it.


## V4 changes
- Mixed Marathi/Hindi/English voice input selector.
- Multi-item editable sale confirmation.
- Editable quantity and unit price before confirmation.
- Paid and Udhar recalculation.
- Confirmation remains required before database mutation.
